# vtigercrmsync para sincronizar VTigerCRM 6.4
