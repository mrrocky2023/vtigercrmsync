<?php
class Sync {}
