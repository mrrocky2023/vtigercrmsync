<?php

$languageStrings = array(
        'Sync' => 'Sync',
        'LBL_WELCOME' => 'A very warm welcome to you'
);
